import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RouterModule, CanActivate } from '@angular/router';
import { promise } from 'protractor';

declare var App: any;

@Injectable({
  providedIn: 'root'
})
export class ContactsViewService {


  private getAllUsersList = App.base_url + 'getAllUsersList';
  private getAddUserReqList = App.base_url + 'getAddUserReqList';
  private addFromAllUser = App.base_url + 'addFromAllUser';

  public contactRowdata: any;

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
  constructor(private http: HttpClient) { }

  getUserList(param: any): Promise<any>{

    return this.http
    .post(this.getAllUsersList, param)
    .toPromise()
    .then(response => response);
  } 

  getRolesList(param: any): Promise<any>{

    return this.http
    .post(this.getAddUserReqList, param)
    .toPromise()
    .then(response => response);
  } 

  createContact(param: any): Promise<any>{

    return this.http
    .post(this.addFromAllUser, param)
    .toPromise()
    .then(response => response);
  } 
  
}
