import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { Param } from '../../custom-format/param';
import { CampaignService } from '../../services/campaign.service';
import { ExportDialogComponent } from '../../dialogs/export-dialog/export-dialog.component';
import { language } from '../../language/language.module';

@Component({
  selector: 'app-campaign-list',
  templateUrl: './campaign-list.component.html',
  styleUrls: ['./campaign-list.component.scss'],
  providers: [CampaignService]
})
export class CampaignListComponent implements OnInit {

  fetchingData: boolean;
  campaignsList: Array<any> = [];
  totalPages: number;
  totalCount: number = 0;
  paginationScroll: boolean;
  public language = language;
  public open = false;

  private param: Param = {
    page: 1,
    perPage: 25,
    sort: 'ASC',
    search: ''
  }
  searching: boolean;
  noCampaigns: boolean;
  selectedCampaign: object = {};

  constructor(
    private campaignService: CampaignService,
    private dialog: MatDialog
  ) { }

  ngOnInit() {
    this.getCampaigns(this.param);
  }

  getCampaigns(param: Object, flag?: string, cb?): void {
    this.noCampaigns = false;
    if (flag == 'pagination') this.paginationScroll = true;
    else this.fetchingData = true;
    this.campaignService
      .getCampaignsList(param)
      .then(response => {
        this.paginationScroll = false;
        this.fetchingData = false;
        this.searching = false;
        if (response.result.success) {
          this.totalCount = response.result.data.count;
          this.totalPages = Math.ceil(Number(this.totalCount) / this.param.perPage);
          if (cb) this.campaignsList = [];
          let data = response.result.data.items;
          data.map(res => {
            this.campaignsList.push(res);
          });
          if (response.result.data.count == 0) this.noRecords();
        }
        else {
          this.noRecords();
        }
      })
      .catch(error => console.log(error))
  }

  private timeout;
  searchCampaign(search: string, event?: any): void {
    this.param.search = search;
    this.param.page = 1;
    this.searching = true;
    if (this.timeout) clearTimeout(this.timeout);
    this.timeout = setTimeout(() => {
      this.getCampaigns(this.param, 'search', () => { });
    }, 1000)
  }

  noRecords(): void {
    this.totalPages = 0;
    this.noCampaigns = true;
    this.campaignsList = [];
    this.selectedCampaign = {};
  }

  onScroll(): void {
    if (this.param.page < this.totalPages && this.totalPages != 0) {
      this.param.page++;
      this.getCampaigns(this.param, 'pagination');
    }
  }

  openDialog(): void {
    let dialogRef = this.dialog.open(ExportDialogComponent, {
      disableClose: true,
      panelClass: 'export-dialog',
      width: '600px',
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result){
        this.totalCount = this.totalCount + 1;
        this.campaignsList.unshift(result);
      }
    });
  }

}
