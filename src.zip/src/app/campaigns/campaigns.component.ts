import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
declare var App: any;
@Component({
  selector: 'app-campaigns',
  templateUrl: './campaigns.component.html',
  styleUrls: ['./campaigns.component.scss'],
  providers: [Title]
})
export class CampaignsComponent implements OnInit {

  constructor(
    private titleService: Title,
  ) { }

  ngOnInit() {
    this.titleService.setTitle(App['company_data'].mainTitle);
  }
  

}
