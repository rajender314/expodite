import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { language } from '../../language/language.module';
import * as moment from 'moment';
import * as _ from 'lodash';

import { CampaignService } from '../../services/campaign.service';

@Component({
  selector: 'app-campaign-details',
  templateUrl: './campaign-details.component.html',
  styleUrls: ['./campaign-details.component.scss'],
  providers: [CampaignService]
})
export class CampaignDetailsComponent implements OnInit {

  detailsForm: FormGroup;
  fetchingData: boolean;
  selectedCampaign: any;
  public language = language;
  gridList: object;

  constructor(
    private fb: FormBuilder,
    private activeRoute: ActivatedRoute,
    private campaignService: CampaignService
  ) { }

  ngOnInit() {
    //this.createForm();
    this.activeRoute.params.subscribe((params: Params) => {
      this.getCampaign(params.id)
    });
  }

  getCampaign(id: string): void {
    this.fetchingData = true;
    this.campaignService
      .viewCampaign({ id: id })
      .then(response => {
        this.fetchingData = false;
        if (response.result.success) {
          this.selectedCampaign = response.result.data;
          //this.setForm(this.selectedCampaign);
          this.gridList = this.selectedCampaign.campaign_details;
        }
      })
      .catch(error => console.log(error))
  }

  /*createForm(): void {
    this.detailsForm = this.fb.group({
      name: [null, Validators.required],
      //budget: [null, Validators.required],
      date_added: [null, Validators.required],
      end_date: [null, Validators.required]
    })
  }*/

  /*setForm(data: any): void {
    this.detailsForm.setValue({
      name: data.name,
      //budget: data.budget,
      date_added: new Date(data.date_added),
      end_date: new Date(data.end_date)
    });
  }*/

  /*cancel(form: any): void {
    form.markAsPristine();
    //this.setForm(this.selectedCampaign);
  }*/

  /*createCampaign(form: any): void {
    if (!form.valid) return;
    let param = {
      id: this.selectedCampaign.id || 0,
      name: form.value.name,
      budget: form.value.budget,
      date_added: moment(form.value.date_added).format('MMM Do, YYYY'),
      end_date: moment(form.value.end_date).format('MMM Do, YYYY')
    }
    // console.log(param);
  }*/

}
