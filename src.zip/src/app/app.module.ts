import { Title } from "@angular/platform-browser";
import { BrowserModule } from "@angular/platform-browser";
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from "@angular/core";
import { DatePipe } from '@angular/common';
import { FormsModule } from "@angular/forms";
import { ReactiveFormsModule } from "@angular/forms";
import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { HttpClientModule } from "@angular/common/http";
import { TimerDirective } from "./timer.directive";
import { InfiniteScrollModule } from "ngx-infinite-scroll";
import { FileUploadModule } from "ng2-file-upload";
import { InputTrimModule } from "ng2-trim-directive";
import { LightboxModule } from 'ngx-lightbox'
import {
  BrowserAnimationsModule,
  NoopAnimationsModule,
} from "@angular/platform-browser/animations";
import { CustomMaterialModule } from "./custom-material/custom-material.module";
import { MatChipsModule } from "@angular/material/chips";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { CommonModule } from "@angular/common";
//import { NgxDatatableModule } from '@swimlane/ngx-datatable';

import { UsersService } from "./services/users.service";
import { CampaignService } from "./services/campaign.service";
import { AdminService } from "./services/admin.service";
import { HttpProviderService } from "./services/http-provider.service";
import { SnakbarService } from "./services/snakbar.service";
import { OrganizationsService } from "./services/organizations.service";
import { InvoicesService } from "./services/invoices.service";

import { HttpInterceptorService } from "./services/http-interceptor.service";

import { AppComponent } from "./app.component";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { UsersComponent } from "./users/users.component";
import { UserDetailsComponent } from "./users/user-details/user-details.component";
import { UserPermissionsComponent } from "./users/user-permissions/user-permissions.component";
import { AdminComponent } from "./admin/admin.component";
import { ClientComponent } from "./admin/client/client.component";
import { ClientListComponent } from "./admin/client/client-list/client-list.component";
import { ClientDetailsComponent } from "./admin/client/client-details/client-details.component";
import { CampaignsComponent } from "./campaigns/campaigns.component";
import { CampaignListComponent } from "./campaigns/campaign-list/campaign-list.component";
import { CampaignDetailsComponent } from "./campaigns/campaign-details/campaign-details.component";
import { ChangePasswordComponent } from "./users/change-password/change-password.component";

import { ContactImageNamePipe } from "./custom-pipes/contact-image-name.pipe";
import { LetterPipe } from "./custom-pipes/letter.pipe";

import { TableComponent } from "./custom-material/table/table.component";
import { SnakbarComponent } from "./custom-material/snakbar/snakbar.component";

import { ExportDialogComponent } from "./dialogs/export-dialog/export-dialog.component";
import { AlertDialogComponent } from "./dialogs/alert-dialog/alert-dialog.component";

import { DashboardRoutingModule } from "./dashboard-routing/dashboard-routing.module";
import { RolesComponent } from "./admin/roles/roles.component";
import { RolesListComponent } from "./admin/roles/roles-list/roles-list.component";
import { RolesDetailsComponent } from "./admin/roles/roles-details/roles-details.component";
import { RolesPermissionsComponent } from "./admin/roles/roles-permissions/roles-permissions.component";
import { DashboardStatsComponent } from "./dashboard/dashboard-stats/dashboard-stats.component";
import { TwitterStatsComponent } from "./dashboard/twitter-stats/twitter-stats.component";

import { ProjectsComponent } from "./projects/projects/projects.component";
import { ObjectivesComponent } from "./projects/objectives/objectives.component";
import { ObjectiveDetailComponent } from "./projects/objective-detail/objective-detail.component";
import { AddObjectiveComponent } from "./projects/add-objective/add-objective.component";
import { AddCampaignComponent } from "./projects/add-campaign/add-campaign.component";
import { OrganizationsComponent } from "./admin/organizations/organizations.component";
import { PricePipe } from "./admin/organizations/organizations-products/price.pipe";
import { OrganizationsDetailsComponent } from "./admin/organizations/organizations-details/organizations-details.component";
import { OrganizationsListComponent } from "./admin/organizations/organizations-list/organizations-list.component";
import { DialogComponent } from "./dialog/dialog.component";
import { OrganizationsContactsComponent } from "./admin/organizations/organizations-contacts/organizations-contacts.component";
import { AddressComponent } from "./dialogs/address/address.component";
import { OrgAddressComponent } from "./admin/address/address.component";
import { OrganizationDocumentsComponent } from "./admin/organizations/organization-documents/organization-documents.component";
import { ContactsComponent } from "./dialogs/contacts/contacts.component";
// import { ContactComponent } from './dialogs/contact/contact.component';
import { ContactDeleteAlertComponent } from "./dialogs/contact-delete-alert/contact-delete-alert.component";
import { AddressDeleteComponent } from "./dialogs/address-delete/address-delete.component";
import { OrganizationsProductsComponent } from "./admin/organizations/organizations-products/organizations-products.component";
import { language } from "./language/language.module";
import { NumberInputDirective } from "./directives/number-input.directive";
import { InputNumberDirective } from "./directives/input-number.directive";
import { InputDatepickerDirective } from "./directives/input-datepicker.directive";
import { OverviewComponent } from "./overview/overview.component";
import { OrdersComponent } from "./orders/orders.component";
import { InvoicesComponent } from "./invoices/invoices.component";
import { ReportsComponent } from "./reports/reports.component";
import { InventoryComponent } from "./inventory/inventory.component";
import { ContainersComponent } from "./admin/containers/containers.component";
import { ProductsComponent } from "./admin/products/products.component";
import { ContactAddressComponent } from "./admin/contact-address/contact-address.component";
import { ContainersDetailsComponent } from "./admin/containers/containers-details/containers-details.component";
import { ContainersListComponent } from "./admin/containers/containers-list/containers-list.component";

import { ContactAddressListComponent } from "./admin/contact-address/contact-address-list/contact-address-list.component";
import { ContactAddressDetailsComponent } from "./admin/contact-address/contact-address-details/contact-address-details.component";
import { ContactAddressPermissionsComponent } from "./admin/contact-address/contact-address-permissions/contact-address-permissions.component";
import { ProductListComponent } from "./admin/products/product-list/product-list.component";
import { ProductDetailsComponent } from "./admin/products/product-details/product-details.component";
import { ContainerDetailsComponent } from "./admin/containers/container-details/container-details.component";
import { AddInventoryComponent } from "./dialogs/add-inventory/add-inventory.component";
import { InventoryDetailsComponent } from "./inventory/inventory-details/inventory-details.component";
import { InventoryListComponent } from "./inventory/inventory-list/inventory-list.component";
import { DeleteInventoryComponent } from "./dialogs/delete-inventory/delete-inventory.component";
//import { InventoryModule } from './inventory/inventory.module';
import { MyDirectiveDirective } from "./directives/my-directive.directive";
import { OrganizationsSettingsComponent } from "./admin/organizations/organizations-settings/organizations-settings.component";
import { CreateOrderComponent } from "./dialogs/create-order/create-order.component";
import { AlertMessageComponent } from "./dialogs/alert-message/alert-message.component";
import { ContainerDeleteComponent } from "./dialogs/container-delete/container-delete.component";
import { ProductsDeleteComponent } from "./dialogs/products-delete/products-delete.component";
import { AddBatchNumberComponent } from "./dialogs/add-batch-number/add-batch-number.component";
import { AddLineItemComponent } from "./dialogs/add-line-item/add-line-item.component";
import { InventoryMergeComponent } from "./inventory/inventory-merge/inventory-merge.component";
import { DeleteLineItemComponent } from "./dialogs/delete-line-item/delete-line-item.component";
import { ShipmentsComponent } from "./admin/shipments/shipments.component";
import { ShipmentDetailsComponent } from "./admin/shipments/shipment-details/shipment-details.component";
import { ShipmentListComponent } from "./admin/shipments/shipment-list/shipment-list.component";
import { UserAccessComponent } from "./dialogs/user-access/user-access.component";
import { NgSelectModule, NgOption } from "@ng-select/ng-select";
import { OrderDownloadComponent } from "./dialogs/order-download/order-download.component";
import { MoreEmailsComponent } from "./dialogs/more-emails/more-emails.component";
import { CancelOrderComponent } from "./dialogs/cancel-order/cancel-order.component";
import { DeliverOrderComponent } from "./dialogs/deliver-order/deliver-order.component";
import { ChangeShipperAddressComponent } from "./dialogs/change-shipper-address/change-shipper-address.component";
import { CategoryComponent } from "./admin/category/category.component";
import { CategoryListComponent } from "./admin/category/category-list/category-list.component";
import { CategoryDetailsComponent } from "./admin/category/category-details/category-details.component";

//import { SuperadminComponent } from './superadmin/superadmin.component';
// import { CronsComponent } from './superadmin/crons/crons.component';
// import { EmailcontrollerComponent } from './superadmin/emailcontroller/emailcontroller.component';
// import { SuperadminService } from './services/superadmin.service';
import { MonthPickerComponent } from "./month-picker/month-picker.component";
import { MarkAsPaidComponent } from "./dialogs/mark-as-paid/mark-as-paid.component";
// import { ContainerDeleteComponent } from './dialogs/container-delete/container-delete.component';

import { OrdersService } from "./services/orders.service";
import { InventoryService } from "./services/inventory.service";
import { PowerConversionDirective } from "./directives/power-conversion.directive";
import { OrganizationsCertificationsComponent } from "./admin/organizations/organizations-certifications/organizations-certifications.component";
import { ClientInstructionComponent } from "./dialogs/client-instruction/client-instruction.component";
import { DeleteInstructionsComponent } from "./dialogs/delete-instructions/delete-instructions.component";
import { ClientProductsComponent } from "./admin/organizations/client-products/client-products.component";
import { ViewInstructionComponent } from "./dialogs/view-instruction/view-instruction.component";
import { DeleteUploadComponent } from "./dialogs/delete-upload/delete-upload.component";
import { AddDrumsComponent } from "./dialogs/add-drums/add-drums.component";
import { EpiCurrencyDirective } from "./directives/epi-currency.directive";
import { EpiCurrencyPipe } from "./pipes/epi-currency.pipe";
import { PowerConversionPipe } from "./pipes/power-conversion.pipe";
import { SalesYtdComponent } from "./reports/sales-ytd/sales-ytd.component";
import { SalesMtdComponent } from './reports/sales-mtd/sales-mtd.component';
import { OrdersbyStatusComponent } from './reports/ordersby-status/ordersby-status.component';
import { OrdersDuebyClientsComponent } from './reports/orders-dueby-clients/orders-dueby-clients.component';
import { PaymentDueComponent } from './reports/payment-due/payment-due.component';
import { ShipmentsReportComponent } from './reports/shipments-report/shipments-report.component';
import { AgGridModule } from 'ag-grid-angular';
import { LicenseManager } from 'ag-grid-enterprise';
LicenseManager.setLicenseKey(
  'Enterpi_Software_Solutions_Private_Limited_MultiApp_1Devs21_August_2019__MTU2NjM0MjAwMDAwMA==f0a6adf3f22452a5a3102029b1a87a43'
);
import { ReportsService } from "./services/reports.service";

// import {MatSelectInfiniteScrollModule} from 'ng-mat-select-infinite-scroll';
import { NgxMatSelectSearchModule } from "ngx-mat-select-search";
import { AuthorizeMailComponent } from "./admin/authorize-mail/authorize-mail.component";
import {
  ReportsDashboardComponent,
  MyFilterPipe,
} from "./reports/reports-dashboard/reports-dashboard.component";

import { FlexLayoutModule } from '@angular/flex-layout';
import { PdfViewerModule } from 'ng2-pdf-viewer';
import { NgxDocViewerModule } from 'ngx-doc-viewer';
import { PdfPreviewComponent } from './dialogs/pdf-preview/pdf-preview.component';
import { EmailDocumentsComponent } from './dialogs/email-documents/email-documents.component';
import { SaveViewComponent } from './dialogs/save-view/save-view.component';
import { VendorComponent } from './admin/vendor/vendor.component';
import { VendorListComponent } from './admin/vendor/vendor-list/vendor-list.component';
import { VendorContactsComponent } from './admin/vendor/vendor-contacts/vendor-contacts.component';
import { VendorProductsComponent } from './admin/vendor/vendor-products/vendor-products.component';
import { VendorDocumentsComponent } from './admin/vendor/vendor-documents/vendor-documents.component';
import { VendorCertificationsComponent } from './admin/vendor/vendor-certifications/vendor-certifications.component';
import { VendorDetailsComponent } from './admin/vendor/vendor-details/vendor-details.component';
import { VendorclientProductsComponent } from './admin/vendor/vendorclient-products/vendorclient-products.component';
import { VendorclientSettingsComponent } from './admin/vendor/vendorclient-settings/vendorclient-settings.component';
import { DeleteViewComponent } from './dialogs/delete-view/delete-view.component';
import { VendorDialogComponent } from './vendor-dialog/vendor-dialog.component';
import { VendorAddressComponent } from './dialogs/vendor-address/vendor-address.component';
import { VendorInstructionsComponent } from './dialogs/vendor-instructions/vendor-instructions.component';
import { VendorDelteInstrnsComponent } from './dialogs/vendor-delte-instrns/vendor-delte-instrns.component';
import { ContactMainviewComponent } from './contact-mainview/contact-mainview.component';
import { TestComponent } from './test/test.component';
import { AddContactComponent } from './dialogs/add-contact/add-contact.component';
import { CreatePurchaseOrderComponent } from './dialogs/create-purchase-order/create-purchase-order.component';
import { TokenExpiredComponent } from './dialogs/token-expired/token-expired.component';

import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
// import { AgeditComponent } from './admin/agedit/agedit.component';
import { LeadAttributesComponent } from './admin/lead-attributes/lead-attributes.component';
import { LeadAtrbtListComponent } from './admin/lead-attributes/lead-atrbt-list/lead-atrbt-list.component';
import { LeadAtrbtDetailComponent } from './admin/lead-attributes/lead-atrbt-detail/lead-atrbt-detail.component';
import { AddAttributeComponent } from './admin/lead-attributes/add-attribute/add-attribute.component';
import { AddAutoAttibuteComponent } from './admin/lead-attributes/add-auto-attibute/add-auto-attibute.component';
// import { HttpClientModule} from '@angular/common/http';
import { AngularEditorModule } from '@kolkov/angular-editor';




declare var App: any;
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
    suppressScrollX: true
  };
   

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    UsersComponent,
    UserDetailsComponent,
    UserPermissionsComponent,
    AdminComponent,
    ClientComponent,
    ClientListComponent,
    ClientDetailsComponent,
    CampaignsComponent,
    CampaignListComponent,
    CampaignDetailsComponent,
    ChangePasswordComponent,
    TableComponent,
    SnakbarComponent,
    ExportDialogComponent,
    AlertDialogComponent,
    ContactImageNamePipe,
    LetterPipe,
    TimerDirective,
    RolesComponent,
    RolesListComponent,
    RolesDetailsComponent,
    RolesPermissionsComponent,
    DashboardStatsComponent,
    ProjectsComponent,
    ObjectivesComponent,
    TwitterStatsComponent,
    ObjectiveDetailComponent,
    AddObjectiveComponent,
    AddCampaignComponent,
    OrganizationsComponent,
    OrganizationsDetailsComponent,
    OrganizationsListComponent,
    DialogComponent,
    OrganizationsContactsComponent,
    AddressComponent,
    OrgAddressComponent,
    OrganizationDocumentsComponent,
    PricePipe,
    ContactsComponent,
    ContactDeleteAlertComponent,
    AddressDeleteComponent,
    OverviewComponent,
    OrganizationsProductsComponent,
    OrdersComponent,
    InvoicesComponent,
    ReportsComponent,
    ReportsDashboardComponent,
    InventoryComponent,
    ContainersComponent,
    ProductsComponent,
    ContactAddressComponent,
    NumberInputDirective,
    InputNumberDirective,
    InputDatepickerDirective,
    ContainersListComponent,
    ContainerDetailsComponent,
    AddInventoryComponent,
    MyDirectiveDirective,
    ContactAddressListComponent,
    ContactAddressDetailsComponent,
    ContactAddressPermissionsComponent,
    ProductListComponent,
    ProductDetailsComponent,
    ContainersDetailsComponent,
    ContainersListComponent,
    OrganizationsSettingsComponent,
    InventoryDetailsComponent,
    InventoryListComponent,
    DeleteInventoryComponent,
    CreateOrderComponent,
    AlertMessageComponent,
    ContainerDeleteComponent,
    ProductsDeleteComponent,
    AddBatchNumberComponent,
    AddLineItemComponent,
    InventoryMergeComponent,
    DeleteLineItemComponent,
    ShipmentsComponent,
    ShipmentDetailsComponent,
    ShipmentListComponent,
    UserAccessComponent,
    OrderDownloadComponent,
    MoreEmailsComponent,
    CancelOrderComponent,
    DeliverOrderComponent,
    ChangeShipperAddressComponent,
    CategoryComponent,
    CategoryListComponent,
    CategoryDetailsComponent,
    MonthPickerComponent,
    MarkAsPaidComponent,
    PowerConversionDirective,
    OrganizationsCertificationsComponent,
    ClientInstructionComponent,
    DeleteInstructionsComponent,
    ClientProductsComponent,
    ViewInstructionComponent,
    DeleteUploadComponent,
    AddDrumsComponent,
    EpiCurrencyDirective,
    EpiCurrencyPipe,
    MyFilterPipe,
    PowerConversionPipe,
    AuthorizeMailComponent,
    SalesYtdComponent,
    SalesMtdComponent,
    OrdersbyStatusComponent,
    OrdersDuebyClientsComponent,
    PaymentDueComponent,
    ShipmentsReportComponent,
    PdfPreviewComponent,
    EmailDocumentsComponent,
    SaveViewComponent,
    VendorComponent,
    VendorListComponent,
    VendorContactsComponent,
    VendorProductsComponent,
    VendorDocumentsComponent,
    VendorCertificationsComponent,
    VendorDetailsComponent,
    VendorclientProductsComponent,
    VendorclientSettingsComponent,
    DeleteViewComponent,
    VendorDialogComponent,
    VendorAddressComponent,
    VendorInstructionsComponent,
    VendorDelteInstrnsComponent,
    ContactMainviewComponent,
    TestComponent,
    AddContactComponent,
    CreatePurchaseOrderComponent,
    TokenExpiredComponent,
   // AgeditComponent,
    LeadAttributesComponent,
    LeadAtrbtListComponent,
    LeadAtrbtDetailComponent,
    AddAttributeComponent,
    AddAutoAttibuteComponent,
    ContainerDeleteComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    FlexLayoutModule,
    ReactiveFormsModule,
    HttpClientModule,
    InputTrimModule,
    //NgxDatatableModule,
    HttpClientModule,
    FileUploadModule,
    InfiniteScrollModule,
    BrowserAnimationsModule,
    CustomMaterialModule,
    DashboardRoutingModule,
    CommonModule,
    MatChipsModule,
    NgSelectModule,
     AngularEditorModule,

    // MatSelectInfiniteScrollModule,
    NgxMatSelectSearchModule,
    AgGridModule.withComponents([

    ]),
    LightboxModule,
    PdfViewerModule,
    NgxDocViewerModule,
    PerfectScrollbarModule,
  ],
  providers: [
    Title,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpInterceptorService,
      multi: true,
    },
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    UsersService,
    CampaignService,
    AdminService,
    SnakbarService,
    OrdersService,
    ReportsService,
    InventoryService,
    OrganizationsService,
    InvoicesService,
    EpiCurrencyPipe,
    MyFilterPipe,
    PowerConversionPipe,
    DatePipe, UsersService, CampaignService, AdminService, SnakbarService,
    OrdersService, InventoryService, OrganizationsService, InvoicesService, EpiCurrencyPipe, PowerConversionPipe
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  entryComponents:[]

})
export class AppModule {
  private language = language;
  constructor(private titleService: Title) {
    this.titleService.setTitle(App["company_data"].mainTitle);
  }
}
