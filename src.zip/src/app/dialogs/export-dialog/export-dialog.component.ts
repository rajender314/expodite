import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { FileUploader } from 'ng2-file-upload';
import { language } from '../../language/language.module';
import { CampaignDetailsComponent } from '../../campaigns/campaign-details/campaign-details.component';

declare var App: any;

@Component({
  selector: 'app-export-dialog',
  templateUrl: './export-dialog.component.html',
  styleUrls: ['./export-dialog.component.scss']
})
export class ExportDialogComponent implements OnInit {
  public hasDropZoneOver: boolean = false;
  public uploader: FileUploader = new FileUploader({
    method: 'POST',
    url: App.base_url + 'importCampaign',
    allowedFileType: ['xls', 'xlsx'],
    maxFileSize: 20 * 1024 * 1024
  });
  loader: number = 1;
  public language = language;
  timmer: any;
  show: boolean;
  pointerEvent: boolean;

  progress(): void {
    this.loader = 1;
    this.timmer = setInterval(() => {
      let remaining = 100 - this.loader;
      this.loader = this.loader + (0.01 * Math.pow(1 - Math.sqrt(remaining), 2))
    }, 100);
  }
  clearProgress(): void {
    clearInterval(this.timmer);
  }

  constructor(
    public dialogRef: MatDialogRef<CampaignDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {dialogRef.disableClose = true;
    this.uploader
      .onAfterAddingFile = (item: any) => {
        this.show = false;
        this.loader = 1;
        this.pointerEvent = true;
      }
    this.uploader
      .onCompleteItem = (item: any, response: any, status: any, headers: any) => {
        this.loader = 100;
        clearInterval(this.timmer);
        let obj = JSON.parse(response);
        if (obj.result.success) {
          this.pointerEvent = false;
          item.isSuccess = true;
          item.isError = false;
          item.message = 'Successfully Uploaded';
          setTimeout(() => {
            this.dialogRef.close(obj.result.data);
          }, 500);
        }
        else {
          item.isSuccess = false;
          item.isError = true;
          //item.message = obj.result.data;
          item.message = obj.result.message;
        }
      };


  }

  ngOnInit() {
    //console.log(this.data);
  }

  fileOverBase(event): void {
    this.hasDropZoneOver = event;
  }

  fileDrop(event): void {
    // console.log(this.uploader.queue)
    // console.log(event)
  }

  fileSelected(event): void {
    // console.log(123)
  }

}
