import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-more-emails',
  templateUrl: './more-emails.component.html',
  styleUrls: ['./more-emails.component.scss']
})
export class MoreEmailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
