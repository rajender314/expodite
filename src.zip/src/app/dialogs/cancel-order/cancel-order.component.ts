import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { OrdersComponent } from '../../orders/orders.component';
import { OrdersService } from '../../services/orders.service';
import { SnakbarService } from '../../services/snakbar.service';


@Component({
  selector: 'app-cancel-order',
  templateUrl: './cancel-order.component.html',
  styleUrls: ['./cancel-order.component.scss'],
  providers: [OrdersService,SnakbarService]
})
export class CancelOrderComponent implements OnInit {
  result: true
  success: boolean;
  constructor(public dialog: MatDialog,
    private OrdersService: OrdersService,
    private snackbar: SnakbarService,
    public dialogRef: MatDialogRef<OrdersComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { dialogRef.disableClose = true;}

  ngOnInit() {
  }
  deleteOrder(): void {

    this.OrdersService

      .acceptOrder({ id: this.data, orders_types_id: 5, typeCancel: 1 })
      .then(response => {
        this.success = true;
        this.dialogRef.close({success: true});
        let toast: object;
        toast = { msg: "Order cancelled successfully.", status: "success" };
        this.snackbar.showSnackBar(toast);
      })
  }
}
