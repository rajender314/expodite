import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { MatInputModule } from '@angular/material/input';
// import {language} from '../../language/language.module'
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDatepicker } from '@angular/material/datepicker';
import * as _ from 'lodash';
import { InventoryService } from '../../services/inventory.service';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { MatChipInputEvent } from '@angular/material/chips';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { language } from '../../language/language.module';
@Component({
  selector: 'app-add-inventory',
  templateUrl: './add-inventory.component.html',
  styleUrls: ['./add-inventory.component.scss'],
  providers: [InventoryService]
})
export class AddInventoryComponent implements OnInit {
  private disableField: boolean = false;
  public submitForm : boolean  =false;
  public InventoryForm: FormGroup;
  maxDate = new FormControl(new Date());
  minDate = new Date();
  public batchServerError: string = '';
  constructor(
    private formBuilder: FormBuilder,
    private InventoryService: InventoryService,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<AddInventoryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { dialogRef.disableClose = true;}

  ngOnInit() {
    this.createForm();
    if (this.data.hasOwnProperty('fieldsData')) {
      if(Object.keys(this.data.fieldsData).length){
        this.disableField = true;
        this.setForm(this.data.fieldsData);
      } else this.disableField = false;
    }
    // console.log(this.data)
  }
  public noWhitespaceValidator(control: FormControl) {
 
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    // [Validators.required , this.noWhitespaceValidator]]
    return isValid ? null : { 'whitespace': true };
}
  createForm() {
    this.InventoryForm = this.formBuilder.group({
      batch_nbr: [null, [Validators.required , this.noWhitespaceValidator]],
      tot_qty: [null, Validators.required],
      category_id: [null, Validators.required],
      mfd_date: [null, Validators.required],
      mergeIds: [null],
      special_instructions: [null],

    });
    this.InventoryForm.get('batch_nbr').valueChanges.subscribe(val => {
      this.batchServerError = '';
    });
  }

  setForm(data): void {
    // console.log(123)
    this.InventoryForm.patchValue({
      category_id: data.categoryId,
      tot_qty: data.totQty,
      mergeIds: data.mergeIds
    });
    if (this.disableField) {
      this.InventoryForm.controls['category_id'].disable();
      this.InventoryForm.controls['tot_qty'].disable();
    }
  }
  selectedDate(event, value): void {
    // console.log(123)
  }

  clearServerError(): void{
    // console.log(123)
    this.batchServerError = '';
  }

  addInventory(form: any): void {
    this.submitForm = true;
    this.InventoryForm.get('batch_nbr').markAsTouched({ onlySelf: true });
    this.InventoryForm.get('tot_qty').markAsTouched({ onlySelf: true});
    this.InventoryForm.get('category_id').markAsTouched({ onlySelf: true });
    this.InventoryForm.get('mfd_date').markAsTouched({ onlySelf: true });
    if (form.valid) {
      let data = Object.assign(this.InventoryForm.value);
      if(this.disableField){
        data.category_id = this.data.fieldsData.categoryId
        data.tot_qty = this.data.fieldsData.totQty
      }
      this.InventoryService
        .addBatch(data)
        .then(response => {
          this.submitForm = false;
          if (response.result.success) {
            let flag = this.data.hasOwnProperty('fieldsData') ? true : false;
            this.dialogRef.close({ success: true, response: response.result.data, flag: flag })

          } else {
            this.batchServerError = response.result.data;
            // this.dialogRef.close({ success: false});
          }
        })
    }


  }

  openCalendar(picker: MatDatepicker<Date>) {
    picker.open();
  }
}

