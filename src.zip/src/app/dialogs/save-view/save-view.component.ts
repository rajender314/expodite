import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { OrdersDuebyClientsComponent } from '../../reports/orders-dueby-clients/orders-dueby-clients.component';
import { UsersService } from '../../services/users.service';
import { SnakbarService } from '../../services/snakbar.service';
import { ReportsService } from '../../services/reports.service';
import * as _ from 'lodash';
@Component({
  selector: 'app-save-view',
  templateUrl: './save-view.component.html',
  styleUrls: ['./save-view.component.scss']
})
export class SaveViewComponent implements OnInit {
  saveViewForm: FormGroup;
  public inProcess: boolean;
  public submitForm :boolean = false;
  public usersList: any = [];
  public errMessage= '';
  constructor(
    private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<OrdersDuebyClientsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private snackbar: SnakbarService,
    private userService: UsersService,
    private reportsService: ReportsService) { }

  ngOnInit() {
    
    this.createForm();
    this.getUserList();
  }
  createForm(): void {
    this.saveViewForm = this.fb.group({
      name: [null, [Validators.required]],
      share: ['0'],
      shared_users: []
    });
  }
  getUserList(): void {
    const param = {
      sort: 'ASC',
    };
    this.userService
      .getUserList(param)
      .then(response => {
        if (response.result.success) {
          this.usersList = response.result.data;
        } 
      })
      .catch(error => console.log(error))
  }
  saveForm() {
    this.inProcess = true;
    if(this.saveViewForm.value.share == '0') {
        this.saveViewForm.value.shared_users = _.map(this.usersList, 'user_id');
    }
    this.submitForm = true;
    const params = {
      view_name: this.saveViewForm.value.name,
      shared_users: this.saveViewForm.value.shared_users,
      applied_filters: this.data.isFiltersApplied ? this.data.filterData : {},
      grid_info: this.data.gridData,
      module: this.data.module
    }
    
    this.reportsService
      .saveViews(params)
      .then(response => {
        this.inProcess = false;
        if (response.result.success) {
          this.usersList = response.result.data.items;
          let currentUserViewId = response.result.data.currentUserViewId;
          setTimeout(() => {
            this.dialogRef.close(currentUserViewId);
            let toastMsg: object;
            toastMsg = { msg: 'View saved successfully', status: 'success' };
            this.snackbar.showSnackBar(toastMsg);
          }, 200);
        } else {
          let toastMsg: object;
            toastMsg = { msg: 'Error while saving View', status: 'error' };
            this.snackbar.showSnackBar(toastMsg);
          this.errMessage = response.result.data.message;
        }
      })
  }
  close() {
    this.dialogRef.close();
  }

}
