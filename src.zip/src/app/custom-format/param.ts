export class Param {
    page: number;
    perPage: number;
    sort: string;
    search?: string;
    
}
