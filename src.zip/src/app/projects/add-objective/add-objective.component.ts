import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-objective',
  templateUrl: './add-objective.component.html',
  styleUrls: ['./add-objective.component.scss']
})
export class AddObjectiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
