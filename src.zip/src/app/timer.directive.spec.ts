import { TimerDirective } from './timer.directive';

describe('TimerDirective', () => {
  it('should create an instance', () => {
    const directive = new TimerDirective();
    expect(directive).toBeTruthy();
  });
});

