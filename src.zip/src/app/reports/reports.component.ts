
import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ViewEncapsulation } from '@angular/core';
import { Images } from '../images/images.module';
import { trigger, style, transition, animate, keyframes, query, stagger } from '@angular/animations';
import * as _ from 'lodash';
declare var App: any;
import { ReportsService } from '../services/reports.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
    trigger('ReportsListAnimate', [
      transition(':enter', [
        style({ transform: 'translateX(-100px)', opacity: 0 }),
        animate('500ms cubic-bezier(0.35, 1, 0.25, 1)', style('*'))
      ])
    ])
  ],
  providers: [Title, ReportsService]
})
  export class ReportsComponent implements OnInit {
  private routerActive = '';
  private images = Images;
  private timeout;
  searching: boolean;
  sideListReports: Array<any> = [
    { id: 1, name: 'Orders by Status (YTD)', route: 'ordersByStatusReport', icon: this.images.roles },
    { id: 2, name: 'Orders Due to Clients', route: 'ordersDueByClientsReport', icon: this.images.roles },
    { id: 3, name: 'Sales Year to Date', route: 'salesYearToDateReport', icon: this.images.containers },
    { id: 4, name: 'Sales Month to Date', route: 'salesMonthToDateReport', icon: this.images.containers },
    { id: 5, name: 'Payment Due', route: 'paymentDueReport', icon: this.images.contactAddress },
    { id: 6, name: 'Shipments', route: 'shipmentsReport', icon: this.images.products },
  ];
  search: string;
  constructor(
    private titleService: Title,
    private ReportsService: ReportsService
  ) { }

  ngOnInit() {
    // console.log(this.images);
    this.titleService.setTitle(App['company_data'].reportsTitle);
  }

  goToList(list) {
    this.ReportsService.reloadRoute(list);
  }
  searchReports(search: string, event?: any): void {
    this.search = search;
    // console.log(this.search);
		// this.page = 1;
		// this.searching = true;
		// if (this.timeout) {
		// 	clearTimeout(this.timeout);
		// }
		// this.timeout = setTimeout(() => {
    //   this.sideListReports(true);
		// }, 1000);
	}

}
