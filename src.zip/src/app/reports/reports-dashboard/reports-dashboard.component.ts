
import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { ViewEncapsulation } from '@angular/core';
import { Images } from '../../images/images.module';
import { trigger, style, transition, animate, keyframes, query, stagger } from '@angular/animations';
import * as _ from 'lodash';
declare var App: any;
import { ReportsService } from '../../services/reports.service';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myfilter',
  pure: false
})
export class MyFilterPipe implements PipeTransform {
  transform(items: any[], filter: string): any {
    if (!items || !filter) {
      return items;
    }
    return items.filter(item => item.name.toLowerCase().indexOf(filter.toLowerCase()) !== -1);
  }
}

@Component({
  selector: 'app-reports-dashboard',
  templateUrl: './reports-dashboard.component.html',
  styleUrls: ['./reports-dashboard.component.scss']
})
export class ReportsDashboardComponent implements OnInit {
  private images = Images;
  public search="";
  constructor() { }
  sideListReports: Array<any> = [
    { id: 1, name: 'Orders by Status (YTD)', route: 'ordersByStatusReport', icon: this.images.roles },
    { id: 2, name: 'Orders Due to Clients', route: 'ordersDueByClientsReport', icon: this.images.roles },
    { id: 3, name: 'Sales Year to Date', route: 'salesYearToDateReport', icon: this.images.containers },
    { id: 4, name: 'Sales Month to Date', route: 'salesMonthToDateReport', icon: this.images.containers },
    { id: 5, name: 'Payment Due', route: 'paymentDueReport', icon: this.images.contactAddress },
    { id: 6, name: 'Shipments', route: 'shipmentsReport', icon: this.images.products },
  ];
  ngOnInit() {
  }
  searchReports(ev): void {

    //this.search = ev;
     console.log(ev);
    
  }
}
