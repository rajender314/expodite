import { NumberInputDirective } from './number-input.directive';

describe('NumberInputDirective', () => {
  it('should create an instance', () => {
    const directive = new NumberInputDirective();
    expect(directive).toBeTruthy();
  });
});
