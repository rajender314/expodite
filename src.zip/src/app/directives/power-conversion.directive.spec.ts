import { PowerConversionDirective } from './power-conversion.directive';

describe('PowerConversionDirective', () => {
  it('should create an instance', () => {
    const directive = new PowerConversionDirective();
    expect(directive).toBeTruthy();
  });
});
