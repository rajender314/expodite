import { InputNumberDirective } from './input-number.directive';

describe('InputNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new InputNumberDirective();
    expect(directive).toBeTruthy();
  });
});
