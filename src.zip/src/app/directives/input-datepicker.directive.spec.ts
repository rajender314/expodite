import { InputDatepickerDirective } from './input-datepicker.directive';

describe('InputDatepickerDirective', () => {
  it('should create an instance', () => {
    const directive = new InputDatepickerDirective();
    expect(directive).toBeTruthy();
  });
});
