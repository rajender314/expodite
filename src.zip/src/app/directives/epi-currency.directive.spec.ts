import { EpiCurrencyDirective } from './epi-currency.directive';

describe('EpiCurrencyDirective', () => {
  it('should create an instance', () => {
    const directive = new EpiCurrencyDirective();
    expect(directive).toBeTruthy();
  });
});
