// import { Routes } from '@angular/router';
// import { InventoryComponent } from '../../inventory/inventory.component';
// import { InventoryDetailsComponent } from '../inventory-details/inventory-details.component';

// export const InventoryRoutingModule = [
//     {
//         path: 'inventory', component: InventoryComponent,
//         children: [
//           { path: 'detail', component: InventoryDetailsComponent }
//         ]
//     }
// ];