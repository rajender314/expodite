import { Component, OnInit, Input, OnChanges, SimpleChange, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import * as _ from 'lodash';

import { Images } from '../../images/images.module';
import { language } from '../../language/language.module';
import { InventoryService } from '../../services/inventory.service';

@Component({
  selector: 'app-inventory-merge',
  templateUrl: './inventory-merge.component.html',
  styleUrls: ['./inventory-merge.component.scss'],
  providers: [InventoryService]
})
export class InventoryMergeComponent implements OnInit, OnChanges {

  @Input('categories') categoryList: Array<any> = [];
  @Output() back = new EventEmitter<any>();
  @Output() addBatch = new EventEmitter<object>();

  public fetchingData: boolean = false;
  private selectAll: boolean = false;
  public pagination = {
    totalCount: 1,
    pageSize: 1
  }
  private params = {
		pageSize: 10,
		page: 1,
    search: '',
    InvproductsArr: [],
    fromDate: '',
    toDate: '',
    type: 'merge'
	}
  private images = Images;
  private language = language;
  public selectedCategory: any = {};
  public checkedBatches = [];
  private batchList = new MatTableDataSource();
  public activeState: boolean = false;
  private totalQuatity = 0;
  private displayedColumns = ['checkbox', 'name', 'mfd_date', 'exp_date', 'tot_qty'];


  constructor(private InventoryService: InventoryService) { }

  ngOnInit() {
    this.activeState = false;
  }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    if (this.categoryList != undefined) {
      if (!_.isEmpty(this.categoryList)) {
        this.selectCategory(this.categoryList[0]);
      }
    }

  }

  resetGrid(category): void{
    this.batchList.data = [];
    this.checkedBatches = [];
    this.totalQuatity = 0;
    this.pagination = {
      totalCount: 1,
      pageSize: 1
    }
    this.params.page = 1;
    this.params.InvproductsArr[0] = category.id;
  }

  selectCategory(category?: any, flag?: boolean): void {
    this.fetchingData = true;
    this.selectAll = false;
    this.selectedCategory = category;
    if(!flag) this.resetGrid(category);
    this.InventoryService
      .BatchesList(this.params)
      .then(response => {
        this.fetchingData = false;
        if (response.result.success) {
          this.pagination.totalCount = response.result.data.count;
          this.pagination.pageSize = response.result.data.lastpage;
          if (this.pagination.totalCount == 0) {
            this.batchList.data = [];
          } else {
            let pre = this.batchList.data;
            let next = response.result.data.batchesDt;
            this.batchList.data = pre.concat(next);
          }
        }
      })
  }


  isSelectAll(isAll: boolean): void {
    this.totalQuatity = 0;
    if (isAll) {
      this.activeState = true; 
      _.map(this.batchList.data, (batch: any)=> {
          batch.isChecked = true;
          this.checkedBatches.push(batch.id);
          this.totalQuatity += batch.remain_quan;
      })
    } else {
      _.map(this.batchList.data, (batch: any) => {
        batch.isChecked = false;
        this.checkedBatches = [];
      })
    }
  }

  isChecked(batch): void {
    let indx = this.checkedBatches.indexOf(batch.id);
    this.activeState = true;
    if (indx > -1) {
      this.checkedBatches.splice(indx, 1);
      this.totalQuatity -= batch.remain_quan;
    }
    else {
      this.checkedBatches.push(batch.id);
      this.totalQuatity += batch.remain_quan;
    }
    if(this.checkedBatches.length == this.batchList.data.length) {
      this.selectAll = true
    } else {
      this.selectAll = false
    }

  }

  createMerge(): void {
    let obj = {
      mergeIds: this.checkedBatches,
      totQty: this.totalQuatity,
      categoryId: this.selectedCategory.id
    }
    this.activeState = false;
    
    this.addBatch.emit(obj)
  }

  cancelMerge(): void {
    this.back.emit();
    this.activeState = false;
  }

  onScroll(): void {
		if (this.params.page < this.pagination.pageSize && this.pagination.pageSize != 0) {
      this.params.page++;
      
			this.selectCategory(this.selectedCategory, true);
		}
	}

}
