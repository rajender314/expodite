import { EpiCurrencyPipe } from './epi-currency.pipe';

describe('EpiCurrencyPipe', () => {
  it('create an instance', () => {
    const pipe = new EpiCurrencyPipe();
    expect(pipe).toBeTruthy();
  });
});
