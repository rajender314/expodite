import { PowerConversionPipe } from './power-conversion.pipe';

describe('PowerConversionPipe', () => {
  it('create an instance', () => {
    const pipe = new PowerConversionPipe();
    expect(pipe).toBeTruthy();
  });
});
