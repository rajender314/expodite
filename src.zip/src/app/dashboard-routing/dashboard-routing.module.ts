import { ContactMainviewComponent } from './../contact-mainview/contact-mainview.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { OverviewComponent } from '../overview/overview.component';
import { UsersComponent } from '../users/users.component';

import { AdminComponent } from '../admin/admin.component';
import { RolesComponent } from '../admin/roles/roles.component';
import { ContainersComponent } from '../admin/containers/containers.component';
import { ShipmentsComponent } from '../admin/shipments/shipments.component';
import { CategoryComponent } from '../admin/category/category.component';
import { AuthorizeMailComponent } from '../admin/authorize-mail/authorize-mail.component';

import { ContactAddressComponent } from '../admin/contact-address/contact-address.component';
import { ProductsComponent } from '../admin/products/products.component';

import { OrganizationsComponent } from '../admin/organizations/organizations.component';
import { OrdersService } from '../services/orders.service';
import { InventoryService } from '../services/inventory.service';
import { AdminService } from '../services/admin.service';
import { UsersService } from '../services/users.service';
import { OrganizationsService } from '../services/organizations.service';
import { InvoicesService } from '../services/invoices.service';
import { VendorComponent } from '../admin/vendor/vendor.component';



import { InvoicesComponent } from '../invoices/invoices.component';
import { ReportsComponent } from '../reports/reports.component';
import { InventoryComponent } from '../inventory/inventory.component';
import { InventoryListComponent } from '../inventory/inventory-list/inventory-list.component';
import { InventoryDetailsComponent } from '../inventory/inventory-details/inventory-details.component';
import { OrdersComponent } from '../orders/orders.component';
import { ChangePasswordComponent } from '../users/change-password/change-password.component';
import { CreateOrderComponent } from '../dialogs/create-order/create-order.component';
import { AlertDialogComponent } from '../dialogs/alert-dialog/alert-dialog.component';
import { SalesYtdComponent } from '../reports/sales-ytd/sales-ytd.component';
import { SalesMtdComponent } from '../reports/sales-mtd/sales-mtd.component';
import { ReportsDashboardComponent } from '../reports/reports-dashboard/reports-dashboard.component';
import { OrdersbyStatusComponent } from '../reports/ordersby-status/ordersby-status.component';
import { OrdersDuebyClientsComponent } from '../reports/orders-dueby-clients/orders-dueby-clients.component';
import { ShipmentsReportComponent } from '../reports/shipments-report/shipments-report.component';
import { PaymentDueComponent } from '../reports/payment-due/payment-due.component';
import { VendorService } from '../services/vendor.service';
import { LeadAttributesComponent } from '../admin/lead-attributes/lead-attributes.component';

declare var App: any;

const routes: Routes = [
  { path: 'overview', component: OverviewComponent },
  { path: 'contactMainView', component: ContactMainviewComponent },
  { path: 'createOrder', component: CreateOrderComponent },
  { path: 'change-password', component: ChangePasswordComponent },
  { path: 'orders', component: OrdersComponent },
  { path: 'inventory', component: InventoryComponent },
  { path: 'reports', component: ReportsComponent,
    children: [
        { path: '', component: ReportsDashboardComponent },
        { path: 'ordersByStatusReport', component: OrdersbyStatusComponent },
        { path: 'ordersDueByClientsReport', component: OrdersDuebyClientsComponent },
        { path: 'salesYearToDateReport', component: SalesYtdComponent },
        { path: 'salesMonthToDateReport', component: SalesMtdComponent },
        { path: 'paymentDueReport', component: PaymentDueComponent },
        { path: 'shipmentsReport', component: ShipmentsReportComponent },      
      // { path: 'containers', component: ContainersComponent },
      // { path: 'address', component: ContactAddressComponent },
      // { path: 'products', component: ProductsComponent },

    ]  
}
  ,
  { path: 'invoices', component: InvoicesComponent  },
  { path: 'users', component: UsersComponent  },
  { path: 'clients', component: OrganizationsComponent  },
  { path: 'vendors', component: VendorComponent },
  {
    path: 'leads',
    loadChildren: () => import('../leads/leads.module').then(m => m.LeadsModule)
  },
  
  {
    path: 'admin', component: AdminComponent ,
    children: [
      { path: '', redirectTo: 'roles', pathMatch: 'full' },
      { path: 'roles', component: RolesComponent },
      { path: 'containers', component: ContainersComponent },
      { path: 'address', component: ContactAddressComponent },
      { path: 'products', component: ProductsComponent },
      { path: 'shipments', component: ShipmentsComponent },
      { path: 'category', component: CategoryComponent },
      { path: 'lead-attribute', component: LeadAttributesComponent },
      { path: 'authorize-gmail', component: AuthorizeMailComponent },
    ]
  },
  { path: '', redirectTo: 'overview', pathMatch: 'full' }


  // { path: 'superAdmin', component: SuperadminComponent,
  //   children: [
  //     { path: '', redirectTo: 'crons', pathMatch: 'full' },
  //     { path: 'crons', component: CronsComponent },
  //     { path: 'emailcontroller', component: EmailcontrollerComponent }
  //   ]
  // }

];
/*App.user_roles_permissions.map(function (value) {
  switch (value.code) {
    case "orders":
      if (value.selected) {
        routes.push({ path: 'orders', component: OrdersComponent });
      }
      break;
    case "inventory":
      if (value.selected) {
        routes.push({ path: 'inventory', component: InventoryComponent });
      }
      break;
    case "reports":
      if (value.selected) {
        routes.push({ path: 'reports', component: ReportsComponent });
      }
      break;
    case "invoices":
      if (value.selected) {
        routes.push({ path: 'invoices', component: InvoicesComponent });
      }
      break;
    case "users":
      if (value.selected) {
        routes.push({ path: 'users', component: UsersComponent });
      }
      break;

    case "clients":
      if (value.selected) {
        routes.push({ path: 'clients', component: OrganizationsComponent });
      }
      break;
    case "admin":
      if (value.selected) {
        routes.push({
          path: 'admin', component: AdminComponent,
          children: [
            { path: '', redirectTo: 'roles', pathMatch: 'full' },
            { path: 'roles', component: RolesComponent },
            { path: 'containers', component: ContainersComponent },
            { path: 'address', component: ContactAddressComponent },
            { path: 'products', component: ProductsComponent },
            { path: 'shipments', component: ShipmentsComponent },
            { path: 'category', component: CategoryComponent },

          ]
        });
      }
      break;
  }
});*/
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class DashboardRoutingModule { }