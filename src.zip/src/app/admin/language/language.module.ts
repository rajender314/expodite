export const language = {
    name: "Kishore"
};