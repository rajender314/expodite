import { Routes } from '@angular/router';

import { AdminComponent } from '../../admin/admin.component';
import { RolesComponent } from '../../admin/roles/roles.component';
import { ContainersComponent } from '../../admin/containers/containers.component';
import { ContactAddressComponent } from '../../admin/contact-address/contact-address.component';
import { ProductsComponent } from '../../admin/products/products.component';
declare var App: any;
export const AdminRoutes: Routes = [
    
];
App.user_roles_permissions.map(function(value){
    switch(value.code){
        case "admin":
            if(value.selected){
                AdminRoutes.push({
                    path: 'admin', component: AdminComponent,
                    children: [
                      { path: '', redirectTo: 'roles', pathMatch: 'full'},
                      { path: 'roles', component: RolesComponent },
                      { path: 'containers', component: ContainersComponent },
                      { path: 'address', component: ContactAddressComponent },
                      { path: 'products', component: ProductsComponent },
                      
                    ]
                });
            }
            break;
    }
}); 