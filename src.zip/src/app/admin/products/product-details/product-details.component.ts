import { Component, OnInit, Input, OnChanges, SimpleChange, Output, EventEmitter ,Inject,ViewChild, ElementRef} from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray } from '@angular/forms';
import { language } from '../../../language/language.module';
import { OrganizationsService } from '../../../services/organizations.service';
import { ProductsDeleteComponent } from '../../../dialogs/products-delete/products-delete.component';
import { VERSION } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSlideToggleModule, MatSlideToggleChange } from '@angular/material/slide-toggle';
import { Images } from '../../../images/images.module';

import { Observable } from 'rxjs/Observable';



import * as _ from 'lodash';

import { AdminService } from '../../../services/admin.service';
import { SnakbarService } from '../../../services/snakbar.service';
import { trigger,style,transition,animate,keyframes,query,stagger } from '@angular/animations';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss'],
  providers: [AdminService, SnakbarService,OrganizationsService],
  animations: [
      trigger('AdminDetailsAnimate', [
          transition(':enter', [
              style({ transform: 'scale(0.8)', opacity: 0 }),
              animate('500ms cubic-bezier(0.35, 1, 0.25, 1)', style('*'))
          ])
      ])
  ]
})
export class ProductDetailsComponent implements OnInit {
  @ViewChild("myInput") inputEl: ElementRef;
  @Input() productType;
  @Input() categoryDt;
  @Output() trigger = new EventEmitter<object>();
  status: Array<object> = [
    { id: 1, value: 'Active', param: true },
    { id: 0, value: 'Inactive', param: false }
  ];  
  detailsForm: FormGroup;
  fetchingData: boolean;
  noProducts: boolean;
  deleteHide:boolean;
  pointerEvent: boolean;
  submitProduct: boolean;
  selectedProducts: any;
  uploads = [];
  categoryData = [];
  addProducts = "Add Product";
  public language = language;
  public images = Images;
  constructor(
    private organizationsService: OrganizationsService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    private snackbar: SnakbarService,
    private adminService: AdminService)
    
     { }

    ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    if(!this.categoryData){
      this.categoryData = this.categoryDt;
    }
       this.noProducts = false;
      this.fetchingData = true;
      setTimeout(() => {
        this.fetchingData = false;
      }, 300);
      if (this.productType != undefined)

      
      if (!_.isEmpty(this.productType)) {
        
        this.detailsForm.reset();
        if (this.productType.hasOwnProperty('flag')) {
          // console.log(this.productType);
          this.addProducts = "Add Product";
          this.noProducts = true;
          this.deleteHide = true;
          this.selectedProducts = {};
        }
        else{
          // console.log(this.productType);  
          this.deleteHide = false;
          this.addProducts = "Update Product";
          if(!this.productType.id){
            this.addProducts = "Add Product";
          }
          this.selectedProducts = _.cloneDeep(this.productType);
          this.submitProduct = false;
          
          this.setForm(this.productType);
          
        } 
      }
      else {
        this.pointerEvent = false;
        
        this.newProduct(true);
      }
  }

  ngOnInit() {
    this.categoryData = this.categoryDt
    this.createForm();
   
  
  }
  newProduct(flag: boolean): void {
   
    if (flag) this.detailsForm.reset();
      this.selectedProducts = {};
      this.deleteHide = true;
      this.productType = {};
      this.fetchingData = false;
      this.inputEl.nativeElement.focus()

  }
  public noWhitespaceValidator(control: FormControl) {
    // console.log('fergrege');
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
}

  createForm(): void {
    this.detailsForm = this.fb.group({
      name: ["", [Validators.required , this.noWhitespaceValidator]],
      description: "",
      price: ["", Validators.required],
      category_id:["", Validators.required],
      status: ["", Validators.required],
    });
  }

  cancel(form: any): void {
    this.submitProduct = false;
    this.selectedProducts = _.cloneDeep(this.productType);
    // console.log(this.selectedProducts)
    form.markAsPristine();
    this.setForm(this.selectedProducts);
  }
  inputEnter($event): void {
    this.detailsForm.markAsDirty();
  }

  createProductType(form: any): void {
    let toast: object;
    // console.log('ferger');
    form.get('name').markAsTouched({ onlySelf: true });
    form.get('price').markAsTouched({ onlySelf: true });
    form.get('category_id').markAsTouched({ onlySelf: true });
    form.get('status').markAsTouched({ onlySelf: true });
    this.submitProduct = true;
    if (!form.valid) {
      return;
    }
    let param = Object.assign({}, form.value);
    param.id = this.selectedProducts.id || 0;
    form.markAsPristine();
    let productIds = [];
    param.priceRange = [];
    this.selectedProducts.priceRange.map(function(value, index){
      param.priceRange.push({id: value.id,price: value.range_price});
    });
   
    this.adminService
      .addProductType(param)
      .then(response => {
        if (response.result.success) {
          form.markAsPristine();
          this.submitProduct = false;
          if (param.id) toast = { msg: response.result.message, status: "success" };
          else toast = { msg: response.result.message, status: "success" };
          this.selectedProducts = response.result.data.ProductRange[0];
          this.trigger.emit({ flag: param.id, data: this.selectedProducts });      
        }
        else {
          toast = { msg: response.result.message, status: "error" };
        }
        this.snackbar.showSnackBar(toast);
      })
      .catch(error => console.log(error))
  }

  deleteItem(form: any): void {
    let toast: object;
    let dialogRef = this.dialog.open(ProductsDeleteComponent, {
      panelClass: 'alert-dialog',
      width: '500px',
      height: '240px',
      data: this.detailsForm.value
    });
    dialogRef.afterClosed().subscribe(result => { 
      if(result.success){
    this.adminService
      .deleteProductType({id:this.selectedProducts.id})
      .then(response => {
        if (response.result.success) {
          form.markAsPristine();
          if (this.selectedProducts.id) toast = { msg: response.result.message, status: "success" };
          else toast = { msg: response.result.message, status: "success" };
          
          this.trigger.emit({ flag: this.selectedProducts.id, delete: true, data: this.selectedProducts });
        }
        else {
          toast = { msg: response.result.message, status: "error" };
        }
        this.snackbar.showSnackBar(toast);
      })
      .catch(error => console.log(error))
    }
  });
   
  }
 

  setForm(data: any): void {
    // console.log(data)
    this.detailsForm.patchValue({
      name: data.name,
      description: data.description,
      price: data.price,
      category_id: data.category_id,
      status: data.status
    });
  }



}
