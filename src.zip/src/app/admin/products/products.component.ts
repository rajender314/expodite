import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

  selectedProduct: object;
  updatedProductDetails: object;
  categoryData: Array<any> = [];

  constructor() { }

  ngOnInit() {
  }
  getSelectedProductType(data: any): void {
    if (data) this.selectedProduct = data;
    else this.selectedProduct = {};
  }

  updateProductDetails(result): void {
    this.updatedProductDetails = {
      
      id: result.flag,
      delete: result.delete?result.delete:false,
      result: result.data
    }
  // console.log(this.updatedProductDetails)
  }
  getCategoryList(result): void {
  this.categoryData = result
  // console.log(this.categoryData)

  }
}
