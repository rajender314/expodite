import { Component, OnInit, Input, OnChanges, SimpleChange, Output, EventEmitter,ViewChild, ElementRef } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { language } from '../../../language/language.module';
import { ContainerDeleteComponent } from '../../../dialogs/container-delete/container-delete.component';
import { Observable } from 'rxjs/Observable';
import { Images } from '../../../images/images.module';
import { VERSION } from '@angular/material/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSlideToggleModule, MatSlideToggleChange } from '@angular/material/slide-toggle';



import * as _ from 'lodash';

import { AdminService } from '../../../services/admin.service';
import { SnakbarService } from '../../../services/snakbar.service';
import { trigger,style,transition,animate,keyframes,query,stagger } from '@angular/animations';

@Component({
  selector: 'app-containers-details',
  templateUrl: './containers-details.component.html',
  styleUrls: ['./containers-details.component.scss'],
  providers: [AdminService, SnakbarService],
  animations: [
      trigger('AdminDetailsAnimate', [
          transition(':enter', [
              style({ transform: 'scale(0.8)', opacity: 0 }),
              animate('500ms cubic-bezier(0.35, 1, 0.25, 1)', style('*'))
          ])
      ])
  ]
})

export class ContainersDetailsComponent implements OnInit {
  @ViewChild("myInput") inputEl: ElementRef;
  @Input() containers;
  @Output() trigger = new EventEmitter<object>();
  public images = Images;
  detailsForm: FormGroup;
  fetchingData: boolean;
  submitContainers:boolean;
  deleteHide:boolean;
  noContainers= true;
  pointerEvent: boolean;
  selectedContainer: any;
  enableInput:boolean;
  addContainers = "Add Container";
  private language = language;
  status: Array<object> = [
    { id: 1, value: 'Active', param: true },
    { id: 0, value: 'Inactive', param: false }
  ]; 
  Crate
Carton
Drum
Container 
  public packageDrpdown = [
    {id: 1, name: 'Crate'},  {id: 2, name: 'Carton'},  {id: 3, name: 'Drum'},  {id: 3, name: 'Container'}
  ]
  constructor(
    private fb: FormBuilder,
    private snackbar: SnakbarService,
    private adminService: AdminService,
    public dialog: MatDialog,
  ) { }

  ngOnChanges(changes: { [propKey: string]: SimpleChange }) {
    this.noContainers = false;
    this.fetchingData = true;
  //  console.log(this.containers)
  //  console.log("vgsdg")
    setTimeout(() => {
      this.fetchingData = false;
    }, 300);
    if (this.containers != undefined)
    
    if (!_.isEmpty(this.containers)) {
this.addContainers = "Update Container"
      this.detailsForm.reset();
      if (this.containers.hasOwnProperty('flag')) {
        this.noContainers = true;
        this.deleteHide = true;
        this.selectedContainer = {};
 
      }
      else{
        this.enableInput = true
        this.deleteHide = false;
        this.noContainers = false;
        this.fetchingData = false;
        this.selectedContainer = this.containers;
        // console.log(this.containers)
        this.setForm(this.containers);
  
      } 

    }
    else {
   
      this.enableInput = false
      this.pointerEvent = false;
      
      this.noContainers = false;
      this.newContainer(true);
    }
  }

  ngOnInit() {
    this.createForm();
  }

  newContainer(flag: boolean): void {
    
    if (flag) this.detailsForm.reset();
      this.selectedContainer = {};
      this.addContainers = "Add Container";
      this.containers = {};
      this.fetchingData = false;
      this.deleteHide = true;
      this.inputEl.nativeElement.focus()
  }

  setDirty(): void {
    this.detailsForm.markAsDirty();
  }
  public noWhitespaceValidator(control: FormControl) {
    // console.log('fergrege');
    let isWhitespace = (control.value || '').trim().length === 0;
    let isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
}

  createForm(): void {
    this.detailsForm = this.fb.group({
      name: [null, [Validators.required , this.noWhitespaceValidator]],
      type_name: ["", Validators.required],
      height: ["", Validators.required],
      weight: ["", Validators.required],
      dimensions: ["", Validators.required],
      status: [null, Validators.required],
      description: "",
      inner_description: [null, Validators.required],
      tare_weight: ["", Validators.required]
    });
  }

  cancel(form: any): void {
    this.submitContainers = false;
    form.markAsPristine();
    // this.setForm(this.selectedContainer);
    this.detailsForm.reset();
  }

  createContainer(form: any): void {
   console.log(form)
    let toast: object;
    this.submitContainers = true;
    if (!form.valid) return;
    let param = Object.assign({}, form.value);
    param.id = this.selectedContainer.id || 0;
    this.adminService
      .addContainer(param)
      .then(response => {
        if (response.result.success) {
          this.noContainers = false;
          this.submitContainers = false;
          form.markAsPristine();
          if (param.id) toast = { msg: response.result.message, status: "success" };
          else toast = { msg: response.result.message, status: "success" };
          this.selectedContainer = response.result.data.ContainersDt[0];
          
          this.trigger.emit({ flag: param.id, data: this.selectedContainer });
        } else {
          toast = { msg: response.result.message, status: "error" };
        }
        this.snackbar.showSnackBar(toast);
      })
      .catch(error => console.log(error))
  }

  deleteContainer(form: any): void {
    let toast: object;
    let dialogRef = this.dialog.open(ContainerDeleteComponent, {
      panelClass: 'alert-dialog',
      width: '500px',
      // height: '240px',
      data: this.detailsForm.value
    });
    dialogRef.afterClosed().subscribe(result => { 
      if(result.success){
    this.adminService
      .deleteContainer({id:this.selectedContainer.id})
      .then(response => {
        if (response.result.success) {
          form.markAsPristine();
          if (this.selectedContainer.id) toast = { msg: response.result.message, status: "success" };
          else toast = { msg: response.result.message, status: "success" };
          this.trigger.emit({ flag: this.selectedContainer.id, delete: true, data: this.selectedContainer });
        }
        else {
          toast = { msg: response.result.message, status: "error" };
        }
        this.snackbar.showSnackBar(toast);
      })
      .catch(error => console.log(error))
    }
  });
  }



  setForm(data: any): void {
   console.log(data)
    this.detailsForm.setValue({
      name: (data && data.name) ? data.name : "",
      status: data.status,
      type_name: (data && data.type_name) ? data.type_name : "",
      height: (data && data.height) ? data.height : "",
      weight: (data && data.weight) ? data.weight : "",
      dimensions: (data && data.dimensions) ? data.dimensions : "",
      description: (data && data.description) ? data.description : "",
      inner_description: (data && data.inner_description) ? data.inner_description : "",
      tare_weight: (data && data.tare_weight) ? data.tare_weight : "",


    });
  }

}