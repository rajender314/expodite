import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import {ViewEncapsulation} from '@angular/core';
import { Images } from '../images/images.module';
import { trigger,style,transition,animate,keyframes,query,stagger } from '@angular/animations';
import * as _ from 'lodash';
declare var App: any;
import { AdminService } from '../services/admin.service';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: [
      trigger('AdminListAnimate', [
          transition(':enter', [
              style({ transform: 'translateX(-100px)', opacity: 0 }),
              animate('500ms cubic-bezier(0.35, 1, 0.25, 1)', style('*'))
          ])
      ])
  ],
  providers: [Title, AdminService]
})
export class AdminComponent implements OnInit {
  private routerActive = '';
  private images = Images;
  sideList: Array<any> = [
    { id: 1, name: 'Roles', route: 'roles', icon: this.images.roles },
    { id: 2, name: 'Packaging', route: 'containers', icon: this.images.containers },
    { id: 3, name: 'Contact Address', route: 'address', icon: this.images.contactAddress },
    { id: 4, name: 'Products', route: 'products', icon: this.images.products },
    { id: 5, name: 'Shipments', route: 'shipments', icon: this.images.shipments },
    { id: 6, name: 'Categories', route: 'category', icon: this.images.category },
    { id: 7, name: 'Lead Attributes', route: 'lead-attribute', icon: this.images.category },

  ];
  constructor(
    private titleService: Title,
    private adminService: AdminService
  ) {}

  ngOnInit() {
    // console.log(this.images);
    this.titleService.setTitle(App['company_data'].AdminTitle);
  }

  goToList(list) {
    this.adminService.reloadRoute(list);
  }

}
