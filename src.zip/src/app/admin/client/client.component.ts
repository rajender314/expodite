import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.scss']
})
export class ClientComponent implements OnInit {

  selectedClient: object;
  updatedDetails: object;

  constructor( ) { }

  ngOnInit() {
  }

  getSelectedClient(data: any): void {
    if (data) this.selectedClient = data;
    else this.selectedClient = {};
  }

  updateDetails(result): void {
    this.updatedDetails = {
      id: result.flag,
      result: result.data
    }
  }

}
